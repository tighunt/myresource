H2status hmacsha256( const H2uint8 *pKeyIn, unsigned int keylen, const H2uint8 *pSrc, H2uint32 ulSrcSize, H2uint8 *pOut );

