#include "hdcp2_hal.h"
#include <sys/time.h>

#include "hdcp2_session.h"
#include "hdcp2_messages.h"
#include "crypto.h"
#include "hdcp2_interface.h"
#include "rcp_api.h"

#define LOG_TAG "HDCP2_SESSION"
#include <utils/Log.h>

#include "HDCP2X_VSN.h"

static h2State gState = H2_STATE_INIT;

static H2bool gbNoStoredEkm = 0;
extern int gPairingState;

/**
 * Functions to process incoming messages
 */

/**
 * Return code:
 * <0 = error
 *  0 = success
 *  1 = success, outgoing message available in *message.
 *
 *  Error codes:
 *  -1 = generic error
 *  -2 = Not enough room in *message for the outgoing message.
 *  -3 = Message received, but gState is not correct for this message.
 *  -4 = Decryption failed.
 */

#define STATUS_ERROR_DECRYPTION_FAILED -4
#define STATUS_ERROR_BAD_STATE -3
#define STATUS_ERROR_JUDGE_LPRIME -5
#define STATUS_ERROR_JUDGE_VPRIME -6
#define STATUS_ERROR_OUTGOING_MSG_TOO_LARGE -2
#define STATUS_OK 0
#if (HDCP_2X_VSN==21)
#define H2_TRANS_RECV_INFO_VERSION 0x01
#elif (HDCP_2X_VSN==22)
#define H2_TRANS_RECV_INFO_VERSION 0x02
#else
#define H2_TRANS_RECV_INFO_VERSION 0x00	// un-used, but give it a initial value
#endif
/**
 * A message is waiting to be sent as a reply
 */
#define STATUS_OK_PENDING_MSG 1

/**
 * On Process AKE Init:
 * Set state to B1 ( Received AKE_INIT )
 * Copy RTX
 * Send AKE_SendCert message
 *
 * Any time AKE Init is received, the state machine is reset, so it
 * can be called from any state.
 *
 */
static int processAkeInit( unsigned char *message, unsigned int length )
{
   static H2_AKEInitPayLoad payload;
   static H2_AKESendCertPayLoad sendPayload;
   int rc=-1;

   /** Zero out session values */
   hdcp2_reset();

   if (!message) {
       return rc;
   }
   
   if (length < (RTX_SIZE +1))
       return rc;
   
   memcpy( payload.rTx, message+1, RTX_SIZE );

   /** Copy RTX value */
   hdcp2_Setrtx( payload.rTx );

   /** Make sure there's room for the outgoing message */
   if ( length < MAX_PACKED_MSG_SIZE )
   {
       ALOGI("No room for outgoing AKE Send Cert message!\r\n");
       rc = STATUS_ERROR_OUTGOING_MSG_TOO_LARGE;
       return rc;
   }

   /** HDCP2 -> HDCP1 repeater */
   sendPayload.repeater = HDCP_REPEATER;

   /** Copy Cert RX into the outgoing message */
   hdcp2_GetCertRx( sendPayload.Cert_rx, sizeof(sendPayload.Cert_rx));

   /** Pack the message for transmission */
   message[0] = AKE_SEND_CERT;  /** Set msgId = AKE_SEND_CERT */
   message[1] = sendPayload.repeater;       /** Set repeater */
   memcpy(message+2, sendPayload.Cert_rx, CERT_RX_SIZE ); 
   length = CERT_RX_SIZE + 2;
   
   //hdcp2.1 repeater
   extern int g_REP_seq_num;
   g_REP_seq_num++;

   /** Everything went okay, so update state */
   gState = H2_STATE_B1_AKE_INIT;

   return STATUS_OK_PENDING_MSG;
}

/**
 * Process Ake No Stored Ekm message.
 *
 * This message is only valid in state B1.
 */

static int processAkeNoStoredEkm( unsigned char *message, unsigned int length )
{
   H2status stat = H2_OK;

   static H2_AKENoStoredEkmPayLoad payload;
   static H2_AKESendrrxPayLoad sendPayload;

   struct timeval tv;

   gbNoStoredEkm = 1;        /* Send Pairing info */
   /** Check state! */
   if ( gState != H2_STATE_B1_AKE_INIT )
   {
      gState = H2_STATE_INIT;      /* Reset state on error */
      ALOGI("AkeNoStoredEkm: no ake init yet\n");
      return STATUS_ERROR_BAD_STATE;
	 }

   if ( length < (EKPUBKM_SIZE + 1 )) {
         ALOGI ("AkeNoStoredEkm msg length is invalid!\r\n");
         return -1;
   }
	 
	 memcpy( payload.EKpub_Km, message+1, EKPUBKM_SIZE );

   /** Copy EKPubKm value */
   gettimeofday(&tv, NULL);
   ALOGI(" -=> dec ekpubKm ake_no_stored_ekm at (%ld, %ld)\n", tv.tv_sec, tv.tv_usec);
   stat = hdcp2_SetEKpubKm( payload.EKpub_Km );
   if ( stat != H2_OK )
   {
       ALOGI("Decryption of EKpubKm failed!\r\n");
       return STATUS_ERROR_DECRYPTION_FAILED;        /** No pending message. Timeout will notify TX of an error */
	 }

   hdcp2_GenrRx();
   hdcp2_GetrRx( sendPayload.rrx, sizeof( sendPayload.rrx) );
   gettimeofday(&tv, NULL);
   ALOGI(" <=- dec ekpubKm ake_no_stored_ekm at (%ld, %ld)\n", tv.tv_sec, tv.tv_usec);
   
   message[0] = AKE_SEND_RRX;
   memcpy( message+1, sendPayload.rrx, RRX_SIZE ); /** Copy rrx */

   length = RRX_SIZE + 1;
   
   /** Set pairing state */
   gPairingState = PAIRING_SEND_HPRIME;

   return STATUS_OK_PENDING_MSG;
}
/**
 * Process Ake Stored Ekm message.
 *
 * This message is only valid in state B1.
 */
					 
static int processAkeStoredEkm( unsigned char *message, unsigned int length )
{
   static H2_AKEStoredEkmPayLoad payload;
   static H2_AKESendrrxPayLoad sendPayload;

   /** Check state! */
   if ( gState != H2_STATE_B1_AKE_INIT )
   {
   		ALOGI("Error: StoredEkm: Bad state\r\n");
      gState = H2_STATE_INIT;      /* Reset state on error */
      return STATUS_ERROR_BAD_STATE;
   }

   gbNoStoredEkm = 0;        /* Don't send pairing info */

   if ( length < (EKHKM_SIZE + M_SIZE + 1 ))
     {
       ALOGI("AkeStored msg length is invalid!\r\n");
       return -1;
     }

   memcpy( payload.EKh_Km, message+1, EKHKM_SIZE );
   memcpy( payload.m, message+1+EKHKM_SIZE, M_SIZE );

   /** Copy EKhKm / m value */
   hdcp2_SetEKhKm( payload.EKh_Km, payload.m );

   /** Generate rRx */
   hdcp2_GenrRx();
   hdcp2_GetrRx( sendPayload.rrx, sizeof(sendPayload.rrx));

   // put rrx message into buffer
   message[0] = AKE_SEND_RRX;
   memcpy(message+1, sendPayload.rrx, RRX_SIZE ); 

   length = RRX_SIZE + 1;

   /** Set pairing state */
   gPairingState = PAIRING_SEND_HPRIME;

   return STATUS_OK_PENDING_MSG;
}

static int processLcInitWithoutPreComputation( unsigned char *message, unsigned int length )
{
   static H2_LCInitPayLoad payload;
   static H2_LCSendLprimePayLoad sendPayload;

    ALOGI("processLcInitWithoutPreComputation: [%d]",__LINE__);


   /** Check state! */
   if (( gState != H2_STATE_B1_AKE_INIT ) && ( gState != H2_STATE_B2_LC_INIT ))
     {
         ALOGI("Error: LcInit: Bad state %d (should be %d)\r\n", gState, H2_STATE_B1_AKE_INIT);
         gState = H2_STATE_INIT;      /* Reset state on error */
         return STATUS_ERROR_BAD_STATE;
      }
   
   if ( length < ( RN_SIZE + 1 ))
     {
       ALOGI("LCINIT Length is invalid!\r\n" );
       return -1;
     }
     
   memcpy( payload.rn, message+1, RN_SIZE );

   /** Copy rn value */
   hdcp2_Setrn( payload.rn );

   /** Copy Lprime into the outgoing message */
   hdcp2_GetlPrime( sendPayload.Lprime, sizeof(sendPayload.Lprime),0); //kelly ?

   /* put message into buffer for transmission */
   message[0] = LC_SEND_L_PRIME;
   memcpy(message+1, sendPayload.Lprime, L_SIZE );
	 length = L_SIZE + 1;

   /** State is B2 */
   gState = H2_STATE_B2_LC_INIT;

   return STATUS_OK_PENDING_MSG;
}

static int processLcInitWithPreComputation( unsigned char *message, unsigned int length )
{
   static H2_LCInitPayLoad payload;
   static H2_LCSendLprimePayLoad sendPayload;
   
   ALOGI("processLcInitWithPreComputation: [%d]",__LINE__);
   
   if (( gState != H2_STATE_B1_AKE_INIT ) && ( gState != H2_STATE_B2_LC_INIT ))
   {
       ALOGI("Error: LcInit: Bad state %d (should be %d)\r\n", gState, H2_STATE_B1_AKE_INIT );
       gState = H2_STATE_INIT;	   /* Reset state on error */
       return STATUS_ERROR_BAD_STATE;
   }	   

   if ( length < ( RN_SIZE + 1 ))
   {
       ALOGI("LC_INIT msg length is invalid!\r\n");
       return -1;
   }
   
   memcpy( payload.rn, message+1, RN_SIZE );
	 
	 /** Copy rn value */
	 hdcp2_Setrn( payload.rn );
	 
   /** Make sure there's room for the outgoing message */
   if ( length < AKE_MSG_SEND_LPRIME_SIZE )
   {
       ALOGI("No room for outgoing SKE Send Lprime message!\r\n");
       return STATUS_ERROR_OUTGOING_MSG_TOO_LARGE;  
   }
	 
	 /** Copy Lprime into the outgoing message & backup it */
	 hdcp2_GetlPrime( sendPayload.Lprime, L_SIZE,1); //kelly ?

	 /** save it */
	 hdcp2_SetLPrime(sendPayload.Lprime);

	 message[0] = RTT_READY;  /** Set msgId = RTT_READY */
	 length = 1;

   return STATUS_OK_PENDING_MSG;
}

static int processAkeTransmitterInfo( unsigned char *message, unsigned int length )
{
   extern unsigned char gPreComputation;
   static H2_AkeTransmitterInfoPayLoad payLoad;
   static H2_AkeReceiverInfoPayLoad sendpayLoad={0};   
   static unsigned int outgoingLength = 0;

   //check valid state
	 if ( gState >= H2_STATE_B2_LC_INIT )
	 {
	 			ALOGI("processAkeTransmitterInfo: Bad state \r\n");
		  	gState = H2_STATE_INIT;	   /* Reset state on error */
		  	return STATUS_ERROR_BAD_STATE;
	 }

   if ( length < (AKE_TRANSMITTER_LENGTH_SIZE+AKE_TRANSMITTER_VERSION_SIZE+AKE_TRANSMITTER_CAPABILITY_MASK_SIZE + 1 ))   /* Skip msgId */
   {
         ALOGI("transmit info msg length is invalid!\r\n");
         return -1;
   }

   /** Copy data */
   memcpy( payLoad.LENGTH, message+1, 2 );
   payLoad.VERSION = *(message+1+2);
   memcpy( payLoad.TRANSMITTER_CAPABILITY_MASK, message+1+2+1, 2 );

   ALOGI("[LY] TRANSMITTER_CAPABILITY_MASK : %d, %d\n", payLoad.TRANSMITTER_CAPABILITY_MASK[0],payLoad.TRANSMITTER_CAPABILITY_MASK[1]);
   
   setPreComputation(payLoad.TRANSMITTER_CAPABILITY_MASK[1]);

   	 // Bruce add after HDCP 2.2, save Transmitter info.
   	 getRTKHDCPSTR()->transmitterVersion=payLoad.VERSION;
   	 getRTKHDCPSTR()->transmitterCapMask[0]=payLoad.TRANSMITTER_CAPABILITY_MASK[0];
   	 getRTKHDCPSTR()->transmitterCapMask[1]=payLoad.TRANSMITTER_CAPABILITY_MASK[1];


	 ALOGI("processAkeTransmitterInfo transmitterVersion :[%d] \r\n",getRTKHDCPSTR()->transmitterVersion);
     ALOGI("processAkeTransmitterInfo transmitterCapMask[0]:[%d] [1]:[%d]\r\n",getRTKHDCPSTR()->transmitterCapMask[0],getRTKHDCPSTR()->transmitterCapMask[1]);

	 //pack the out-going packet
	 //version
	 sendpayLoad.VERSION = H2_TRANS_RECV_INFO_VERSION;
	 //mask
	 //if the transmitter doesn't have the capability to do the pre-computation, we don't said that we have
	 if ((getPreComputation()&0x01) == H2_LC_INIT_PRECOMPUTATION)
	 {
		 // check HDCP version, note that this function would be called after HDCP 2.1
		#if (HDCP_2X_VSN == 21)
		setHDCPCAP(CAP_HDCP2_1);		// gHDCP2_1 = CAP_HDCP2_1;
		#elif (HDCP_2X_VSN == 22)
		setHDCPCAP(CAP_HDCP2_2);		// Bruce add for HDCP2.2
		#else
		setHDCPCAP(CAP_HDCP2_0);		// Bruce add for HDCP2.0
		#endif
	 }

	if(IsCapHDCP2Plus())
		sendpayLoad.RECEIVER_CAPABILITY_MASK[1] = H2_LC_INIT_PRECOMPUTATION;
	else
		sendpayLoad.RECEIVER_CAPABILITY_MASK[1] = H2_LC_INIT_NO_PRECOMPUTATION;
	sendpayLoad.RECEIVER_CAPABILITY_MASK[0] = 0x00; //reserved

	 // Bruce add after HDCP 2.2, save Receiver Info.
	 getRTKHDCPSTR()->receiverVersion=sendpayLoad.VERSION;
	 getRTKHDCPSTR()->receiverCapMask[0]=sendpayLoad.RECEIVER_CAPABILITY_MASK[0];
	 getRTKHDCPSTR()->receiverCapMask[1]=sendpayLoad.RECEIVER_CAPABILITY_MASK[1];
	 
	 	ALOGI("receiverVersion :[%d] \r\n",getRTKHDCPSTR()->receiverVersion);

	 //length
	 sendpayLoad.LENGTH[0] = 0x00;
	 sendpayLoad.LENGTH[1] = AKE_RECEIVER_INFO_PAYLOAD_SIZE+1;
	 ALOGI("[LY] RECEIVER CAPABILITY MASK: %d, %d\n", sendpayLoad.RECEIVER_CAPABILITY_MASK[0], sendpayLoad.RECEIVER_CAPABILITY_MASK[1]);
		
   message[0] = AKE_RECEIVER_INFO;  /** Set msgId = AKE_RECEIVER_IFNO */
	 memcpy(message+1, &sendpayLoad, AKE_RECEIVER_INFO_PAYLOAD_SIZE);
   /* pack the LENGTH, VERSION, RECEIVER_CAPABILITY_MASK outside the caller function  */
   length = AKE_RECEIVER_INFO_PAYLOAD_SIZE + 1;
		
   /** Signal that a message is waiting */
	 //following the hdcp2.0 spec. we don't reply for this pkt
   //	#if (HDCP_2X_VSN == 21)
   //		return STATUS_OK_PENDING_MSG;
   //	#else
   //		return -1;
   //	#endif

    ALOGI("[hdcp kelly] return STATUS_OK_PENDING_MSG");
   	if(IsCapHDCP2Plus())
   		return STATUS_OK_PENDING_MSG;
   	else
   		return -1;
}

static int processRTTChallenge( unsigned char *message, unsigned int length )
{
	   H2status ret;
	
	   /**
	 	 * These two are static to keep them off the stack.
		 */
	   static H2_AkeRTTChallengePayLoad payload;
	   static H2_LCSendMostLprimePayLoad sendPayload;
     static H2_LCSendMostLprimePayLoad MostLPrime;
	
		 /** Check state! */	
		 if (( gState != H2_STATE_B1_AKE_INIT ) && ( gState != H2_STATE_B2_LC_INIT ))
		 {
		   ALOGI("Error: LcInit: Bad state %d (should be %d)\r\n", gState, H2_STATE_B1_AKE_INIT );
			 gState = H2_STATE_INIT;	  /* Reset state on error */
			 return STATUS_ERROR_BAD_STATE;
		 }
		 
     if ( length < ( (L_SIZE/2) + 1 ))
     {
         ALOGI( "RTTChallenge pkt length is invalid!\r\n" );
         return -1;
     }

     /** Copy data */
     memcpy( payload.L, message+1, (L_SIZE/2) );

		 /** judge the least 128bits of L */
		 ret = hdcp2_JudgeLeastLPrime( &payload, sizeof(payload.L));
		 if (ret == H2_ERROR)
		 {
			  ALOGI( "Error: JudgeLeastLPrime fail\r\n" );
			  gState = H2_STATE_INIT;	   /* Reset state on error */
			  return STATUS_ERROR_JUDGE_LPRIME;
		 }
	
		 /** Make sure there's room for the outgoing message */
		 if ( length < AKE_MSG_SEND_MOST_LPRIME_SIZE )
		 {
			 ALOGI( "No room for outgoing most 128bits of LC_Send_L_Prime message!\r\n");
			 return STATUS_ERROR_OUTGOING_MSG_TOO_LARGE;
		 }
	
		 /** Copy Lprime into the outgoing message */		  
		 hdcp2_GetMostlPrime( sendPayload.MostLprime, sizeof(sendPayload.MostLprime));
	
     message[0] = LC_SEND_L_PRIME;  /** Set msgId = LC_SEND_L_PRIME */
     memcpy( message+1, sendPayload.MostLprime, L_SIZE/2 ); /** Copy Lprime */
     length = (L_SIZE/2) + 1;
	
		 /** State is B2 */
		 gState = H2_STATE_B2_LC_INIT;
	
	   return STATUS_OK_PENDING_MSG;
}

	static int processRepAuthStreamManage ( unsigned char *message, unsigned int length )
	{
		int i;
		H2status stat = H2_OK;
		
		static H2_RepeaterAuthStreamManage_PayLoad payload={0};
		static H2_RepeaterAuthReady_PayLoad sendPayload={0};
		
		/* judge V and V' */
		//Gen. M Prime
		hdcp2_GetMPrime(&sendPayload, message, length);
		
    message[0] = REP_AUTH_STREAM_READY;  /** Set msgId = RECEIVER_AUTH_STATUS */
	  memcpy(message+1, sendPayload.MPrime, MPRIME_SIZE);
    length = MPRIME_SIZE + 1;
		
		return STATUS_OK_PENDING_MSG;
	}

static int processRepAuthSendAck ( unsigned char *message, unsigned int length )
{
	int i;
	H2status stat = H2_OK;
	
	static H2_RepeaterAuthSendACK_PayLoad payload;
	static H2_ReceiverAuthStatus_PayLoad sendPayload={0};
	
	/** Unpack RepAuthSendAck message */
	#if 0
	ALOGI("[LY] Rep Auth Send ACK \n:");
	for (i=0;i<17;i++)
		ALOGI("%02x ", message[i]);
	ALOGI("\n");
	#endif

	/** Check length */
	if ( length < ( (V_SIZE/2) + 1 ))
	{
	  ALOGI( "RepAuthSendAck pkt Length is invalid!\r\n" );
	  return -1;
	}
	
	/** Copy data */
	memcpy( payload.V, message+1, (V_SIZE/2) );

	//1. judge validation V & V'
	if (hdcp2_JudgeLeastVPrime(payload.V, V_SIZE/2) != 0)
	{
	 	ALOGI( "Error unpacking message!\r\n");
	 	return STATUS_ERROR_JUDGE_VPRIME;
	}
	//TODO: 
	//2. receiving RepeaterAuth_Send_Ack within 200MS or not
	
	// if fail, REAUTH_REQ = true, 0x01
	sendPayload.LENGTH[0]=0x00;
	sendPayload.LENGTH[1]=RECEIVERAUTHSTATUS_SIZE+1; //following spec.	   
	sendPayload.REAUTH_REQ = 0x00; //false = pass 
	
  message[0] = RECEIVER_AUTH_STATUS;  /** Set msgId = RECEIVER_AUTH_STATUS */
	memcpy(message+1, sendPayload.LENGTH, 2);
	message[3] = sendPayload.REAUTH_REQ;
  length = RECEIVERAUTHSTATUS_SIZE + 1;

	return STATUS_OK_PENDING_MSG;
}

static int processSkeSendEks( unsigned char *message, unsigned int length )
{
   static H2_SKESendEksPayLoad payload;
   static H2_RepeaterAuthSendRxIdList_PayLoad sendPayload = {0};
   static H2uint8 ksvs[RECEIVERID_SIZE*MAX_DEVICECOUNT];
   static unsigned int outgoingLength = 0;
   int ret;

   if ( gState != H2_STATE_B2_LC_INIT )
   {
      ALOGI("SkeSendEks: Bad State\r\n");
      gState = H2_STATE_INIT;      /* Reset state on error */
      return STATUS_ERROR_BAD_STATE;
   }

   if ( 0 != h2MsgRepeaterAuthSendReceiverIdListPack( NULL, &outgoingLength, &sendPayload, ksvs ))
   {
      ALOGI( "Error determing length of RX ID Message\r\n");
      return -1;
   }
   if ( length < outgoingLength )
   {
      ALOGI( "No room for outgoing RX ID list message!\r\n");
      return STATUS_ERROR_OUTGOING_MSG_TOO_LARGE;
   }

   /** Check length */
   if ( length < ( EDKEYKS_SIZE + RIV_SIZE + 1 ))
   {
      ALOGI( "Length is invalid!\r\n" );
      return -1;
   }

   /** Copy data */
   memcpy( payload.Edkey_Ks, message+1, EDKEYKS_SIZE );
   memcpy( payload.riv, message+EDKEYKS_SIZE+1, RIV_SIZE );

   /** Transition to state B3 */
   gState = H2_STATE_B3_SKE_SEND_EKS;

   /** Copy EdKeyKs value */
   hdcp2_SetEdKeyKs( payload.Edkey_Ks );

   /** Copy riv */
   hdcp2_SetRiv( payload.riv );

	 /*
	  * Don't send KSV if we're not a repeater.
	  */
#if (HDCP_REPEATER == 1)
	  H2uint8 DeviceCount;
	  H2uint8 Depth;
	  H2uint8 DepthExceeded;
	  H2uint8 DevicesExceeded;
			
	  hdcp2_GetKsvInfo( &DeviceCount, &Depth, &DevicesExceeded, &DepthExceeded, ksvs );
	  	  
	  if ( DeviceCount || DepthExceeded || DevicesExceeded )
	  {
	  	hdcp2_GetKsvInfo( &sendPayload.deviceCount, &sendPayload.depth, 
  	     &sendPayload.maxDevsExceeded, &sendPayload.maxCascadeExceeded , 
		      (H2uint8 *)ksvs );
	  
			/** Copy Vprime into the outgoing message */
			hdcp2_GetvPrime( sendPayload.VPrime, sizeof( sendPayload.VPrime ) );

			hdcp2_SaveStringInFile("/tmp/_vprime2", sendPayload.VPrime, sizeof( sendPayload.VPrime ));
	  
			if ( 0 != h2MsgRepeaterAuthSendReceiverIdListPack( message, &length, &sendPayload, ksvs ))
			{
		  	ALOGI( "Error packing Rx Id list\r\n");
		  	return -1;
			}

  		hdcp2_SaveStringInFile("/tmp/_ReceiverIdListPack1", message, length);
	    
			/** Success, Send KSVs */
			ret = STATUS_OK_PENDING_MSG;
	  }
	  else
	  {
			ret = STATUS_OK;
	  }
#endif

    /** State is B4 */
    gState = H2_STATE_B4_AUTHENTICATED;
	  #ifdef HDCP2_1
      ALOGI("HDCP2.1 nego success!\n");
	  #else
      ALOGI("HDCP2.0 nego success!\n");
	  #endif

   return ret;
}


h2State h2StateGet( void )
{
   return gState;
}

int h2MessagePoll( unsigned char *message, unsigned int length )
{
   int rc = 0;

   switch ( gPairingState )
   {
      case PAIRING_INIT:
         break;
      case PAIRING_SEND_HPRIME:
         {
  		    H2uint8 Kd_tmp[KD_SIZE];		 	
            static H2_AKESendHprimePayLoad sendPayload;
            /** Make sure there's room for the outgoing message */
            if ( length < AKE_MSG_SEND_HPRIME_SIZE )
            {
            	 ALOGI("buffer too small for AKE Send Hprime message!\r\n");
               rc = STATUS_ERROR_OUTGOING_MSG_TOO_LARGE;
               break;
            }

            int modeHDCP22=0;
            if(getHDCPCAP()==CAP_HDCP2_2 && getRTKHDCPSTR()->transmitterVersion==0x2)
				modeHDCP22=1;

			RCP_HDCP2_GenKd(SRAM_KM_ENTRY, SessionSecrets.rtx, SessionSecrets.rRx,SessionSecrets.rn, SRAM_KD_ENTRY,modeHDCP22);
			spu_GetKD(Kd_tmp);
			
			/** Compute HPrime from Kd, RTX, and Repeater */
			/** Copy Hprime into the outgoing message */
			if(getHDCPCAP()==CAP_HDCP2_2 && getRTKHDCPSTR()->transmitterVersion==0x2)
			{
				ALOGI( "h2MessagePoll[%d] 2.2 case!\r\n",__LINE__);
				Compute_Hprime_22(Kd_tmp,SessionSecrets.rtx,HDCP_REPEATER,
						getRTKHDCPSTR()->receiverVersion,getRTKHDCPSTR()->receiverCapMask,
						getRTKHDCPSTR()->transmitterVersion,getRTKHDCPSTR()->transmitterCapMask,
						SessionSecrets.hPrime);
			}
			else
			{
				ALOGI( "h2MessagePoll[%d] 2.0 2.1 case!\r\n",__LINE__);
				Compute_Hprime(Kd_tmp, SessionSecrets.rtx, HDCP_REPEATER, SessionSecrets.hPrime);
			}
			memset(Kd_tmp, 0x00, KD_SIZE);
			
            /** Copy Hprime into the outgoing message */
            hdcp2_GethPrime( sendPayload.Hprime, sizeof(sendPayload.Hprime));

            /** Pack the message for transmission */
			      message[0] = AKE_SEND_H_PRIME;
      			memcpy( message+1, sendPayload.Hprime, H_SIZE ); /** Copy rrx */

            /** Signal that a message is waiting */
            rc = STATUS_OK_PENDING_MSG;
            gPairingState = (gbNoStoredEkm ? PAIRING_SEND_PAIRING_INFO : PAIRING_INIT );
         }
         break;
      case PAIRING_SEND_PAIRING_INFO:
         {
            static H2_AKESendPairingInfoPayLoad sendPayload;

            hdcp2_GetEKhKm( sendPayload.Ekh_Km, sizeof( sendPayload.Ekh_Km ));

      			message[0] = AKE_SEND_PAIRING_INFO;
      			memcpy( message+1, sendPayload.Ekh_Km, EKHKM_SIZE ); /** Copy rrx */
						length = EKHKM_SIZE + 1;

            gPairingState = PAIRING_INIT;
            rc = STATUS_OK_PENDING_MSG;
         }
         break;
      default:
         gPairingState = PAIRING_INIT;
         break;
   }
   return rc;
}

void h2Init( void )
{
   extern int g_REP_seq_num;
   extern int RXID_LIST_200MS_TIMEOUT_STATE;
   gState = H2_STATE_INIT;

   gbNoStoredEkm = 0;

   gPairingState = PAIRING_INIT;
   
   g_REP_seq_num = -1;

   /* set default pre-computation to false */
    setPreComputation(H2_LC_INIT_NO_PRECOMPUTATION);

   RXID_LIST_200MS_TIMEOUT_STATE = RXID_200MS_TIMEOUT_UNDEF;
   
   return;
}


int h2MessageParse( unsigned char *message, unsigned int length )
{
   int rc = 0;
   do
   {

      if ( NULL == message )
      {
         break;
      }
      unsigned char msgId = *message;
      
      switch( msgId )
      {
         /**
          * TX -> RX messages
          */
         case AKE_INIT:
            rc = processAkeInit( message, length );
            break;
         case AKE_NO_STORED_EKM:
            rc = processAkeNoStoredEkm( message, length );
            /** Start pairing process */
            gPairingState = PAIRING_SEND_HPRIME;
            break;
         case AKE_STORED_EKM:
            rc = processAkeStoredEkm( message, length );
            gPairingState = PAIRING_SEND_HPRIME;
            break;
         case LC_INIT:
					 	if (((getPreComputation()&0x01) == H2_LC_INIT_PRECOMPUTATION) && (IsCapHDCP2Plus()))
					 	{
			            	rc = processLcInitWithPreComputation( message, length );
					 	}
						else
						{
			            	rc = processLcInitWithoutPreComputation( message, length );			
						}            
            break;
				 case RTT_CHALLENGE:
				 		rc = processRTTChallenge( message, length );	
				 		break;   
		 		 case AKE_TRANSMITTER_INFO: //for hdcp2.1
		 		    rc = processAkeTransmitterInfo( message, length );
				 		break;
         case SKE_SEND_EKS:
            rc = processSkeSendEks( message, length );
            break;
		 case REP_AUTH_SEND_ACK:
		 	rc = processRepAuthSendAck(message, length);
			break;
		 case REP_AUTH_STREAM_MANAGE:		 	
		 	rc = processRepAuthStreamManage(message, length);
			break;
            /**
             * RX -> TX messages. We should not receive these!
             */
         case AKE_SEND_CERT:
         case AKE_SEND_RRX:
         case AKE_SEND_H_PRIME:
         case AKE_SEND_PAIRING_INFO:
         case LC_SEND_L_PRIME:
         case REP_AUTH_SEND_RXID_LIST:
            ALOGI("TX received on RX!\n");
            /* TODO: Error handling? */
            rc = -1;
            break;
         default:
            ALOGI("HDCP received unknown message\n");
            rc = -2;
            break;
      }


   } while( 0 );

   return rc;
}

int h2MsgRepeaterAuthSendReceiverIdListPack( unsigned char *pMsg, unsigned int *pLength, const H2_RepeaterAuthSendRxIdList_PayLoad *payload, const H2uint8 *rcvrIds )
{
   int rc = 0;
   unsigned int ulSize = 0;
   unsigned int ii;
   int i;
   unsigned char num_V[4]={0};
   int rxidResult_size=0;

   if (IsCapHDCP2Plus())
   	rxidResult_size = REPEATERAUTHLIST_BASE_SIZE_H21;
   else
   	rxidResult_size = REPEATERAUTHLIST_BASE_SIZE_H20;

   do
   {
      /** If pMsg is NULL, return how many bytes are needed for the
       * message in *pLength
       */
      if ( NULL != payload )
      {
         if (( payload->maxDevsExceeded ) || ( payload->maxCascadeExceeded ))
         {
            ulSize = 3;
         }
         else
         {
            ulSize = rxidResult_size +
               payload->deviceCount*RECEIVERID_SIZE;
         }
      }

      if ( NULL == payload )
      {
         /** Need payload to determine message size */
         rc = -1;
         break;
      }

      if ( NULL == pMsg )
      {
         if ( NULL != pLength )
         {
            *pLength = ulSize;

            rc = 0;
            break;
         }
         else
         {
            /** Need pLength or pMsg */
            rc = -1;
            break;
         }
      }

      if ( NULL == rcvrIds )
      {
         if (( 0 == payload->maxDevsExceeded ) &&
            ( 0 == payload->maxCascadeExceeded ))
         {
            /** Receiver ID list cant be null
             * if cascade or devs are not exceeded.
             */
            rc = -1;
            break;
         }
      }
      if (( pLength ) && ( *pLength < ulSize))
      {
         ALOGI( "Error: Message is not large enough\n" );
         *pLength = ulSize;
         rc = 1;
         break;
      }

      pMsg[0] = REP_AUTH_SEND_RXID_LIST;
      pMsg[1] = payload->maxDevsExceeded;
      pMsg[2] = payload->maxCascadeExceeded;
      if (( payload->maxDevsExceeded ) || ( payload->maxCascadeExceeded ))
      {
         ulSize = 3;
         rc=0;
         break;
      }
      pMsg[3] = payload->deviceCount;
      pMsg[4] = payload->depth;
	  if (IsCapHDCP2Plus())
	  {
		  extern int g_REP_seq_num;
		  extern H2_gKsvInfo gKsvInfo;
		  LTB4(num_V[0], num_V[1], num_V[2], num_V[3], g_REP_seq_num);
	      pMsg[5] = gKsvInfo.HDCP20RepeaterDownStream;//gKsvInfo.HDCP20RepeaterDownStream;
	      pMsg[6] = gKsvInfo.HDCP1DeviceDownStream;//gKsvInfo.HDCP1DeviceDownStream;
		  pMsg[7] = num_V[1];
		  pMsg[8] = num_V[2];
		  pMsg[9] = num_V[3];
	      memcpy( pMsg+10, payload->VPrime, V_SIZE/2 ); /** Copy most 128 bits of Lprime */
	  }
	  else
	      memcpy( pMsg+5, payload->VPrime, V_SIZE ); /** Copy VPrime */

      for( ii=0; ii<payload->deviceCount;ii++)
      {
      	if (IsCapHDCP2Plus())
        	memcpy( pMsg+10+V_SIZE/2+ii*RECEIVERID_SIZE , rcvrIds+ii*RECEIVERID_SIZE, RECEIVERID_SIZE );
		else
	        memcpy( pMsg+5+V_SIZE+ii*RECEIVERID_SIZE , rcvrIds+ii*RECEIVERID_SIZE, RECEIVERID_SIZE );
      }
	  
	  if (IsCapHDCP2Plus())
	  {
		  hdcp2_SetLeastVPrime(payload->VPrime);
		  hdcp2_SaveStringInFile("/tmp/_vprime1", payload->VPrime, V_SIZE);
	  }

      if ( pLength )
      {
         *pLength = ulSize;
      }

      rc = 0;
      break;
   } while( 0 );

   return rc;
}

